export J2EE_HOME=/opt/glassfish4/glassfish/
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64/
export PATH=/usr/lib/jvm/java-8-openjdk-amd64/bin:${PATH}
